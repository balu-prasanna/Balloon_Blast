#include <iostream>
#include <time.h>
#include <GL/freeglut.h>
#include "definations.h"
#include "callbackfunctions.h"

using namespace std;

void init();

int main(int argc, char **argv) {

    // Initialize GLUT
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowPosition(0, 0);
    glutInitWindowSize(WIDTH, HEIGHT);
    glutCreateWindow("Balloon Blast");

    // Register all callback functions
    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(normalKeys);

    init();

    glutMainLoop();

    return 0;
}

void init() {

    time_t t;
    srand((unsigned int) time(&t));

    glClearColor(0, 0, 0, 0);
}
