#ifndef GAME_H
#define GAME_H

#include "definations.h"

extern AppState appState;
extern GameState gameState;
extern bool instructionMenuVisible;

void initGame();
void startScreen();
void gameScreen();
void updateGameState();
void notifyGame(int val);
void fire(unsigned char key);


#endif //GAME_H

