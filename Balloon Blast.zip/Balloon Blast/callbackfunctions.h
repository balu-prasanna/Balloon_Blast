#ifndef CALLBACKFUNCS_H
#define CALLBACKFUNCS_H

void display();

void idle();

void reshape(int w, int h);

void normalKeys(unsigned char key, int x, int y);

void timerFunc(int n);

#endif //CALLBACKFUNCS_H
