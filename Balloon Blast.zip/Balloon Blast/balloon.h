#ifndef BALLOON_H
#define BALLOON_H

#include <GL/gl.h>
#include "definations.h"

class Balloon {

public:
    char key[2] = {'A', '\0'};
    vec2f pos;
    bool flewAway;
    bool alive;

    Balloon();
    void draw();
    void updatePos(float gameSpeed);
    bool isHit(char key);
};

#endif // BALLOON_H
