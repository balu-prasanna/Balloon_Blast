#include <stdlib.h>
#include "definations.h"
#include "game.h"
#include "fonts.h"
#include <sstream>
#include <vector>
#include <algorithm>
#include "balloon.h"
#include <GL/freeglut.h>
#include <unistd.h>

using namespace std;

AppState appState = START_SCREEN;
GameState gameState = ROUND_INIT;
bool instructionMenuVisible = true;
bool notifyMsg = false;
int score;
string msg;
float gameSpeed;
int balloonCount;
int gameLevel;

vector<int> balloonIndices;

Balloon balloons[MAX_BALLOON_CNT];

void initRound();
void showInstructions();
void showDebugInfo();
void drawBackground();
void drawCursor();
void drawBalloons();
void chooseRandomBalloons(int n);
void initializeAllBalloons();

void initGame() {
    balloonCount = INITIAL_BALLOON_CNT;
    gameLevel = 1;
    gameSpeed = 1.0f;
    score = 0;
    initRound();
}

void initRound() {
    gameState = ROUND_INIT;
    notifyMsg = false;
    glutTimerFunc(100, notifyGame, 0);
    initializeAllBalloons();
    chooseRandomBalloons(balloonCount);
}

void initializeAllBalloons() {
    for (int i = 0; i < MAX_BALLOON_CNT; i++) {
        balloons[i].key[0] = 'A' + i;
        balloons[i].pos.x = 100 + (BALLOON_RAD_X*2 * (rand() % ((WIDTH-200)/(BALLOON_RAD_X*2))));
//        cout << "Balloon " << i << ": " << balloons[i].pos.x << endl;
        balloons[i].pos.y = 0;
        balloons[i].alive = true;
        balloons[i].flewAway = false;
    }
}

void chooseRandomBalloons(int n) {
    balloonIndices.clear();
    while (balloonIndices.size() < n) {
        int x = rand() % MAX_BALLOON_CNT;
        if (balloonIndices.size() != 0 && find(balloonIndices.begin(), balloonIndices.end(), x) != balloonIndices.end())
            continue;
        balloonIndices.push_back(x);
    }
}

void startScreen() {

    glLineWidth(3);
    drawStrokeText("BALLOON BLAST", WIDTH/5-100, 3*HEIGHT/4, 0, FONT_SIZE_BIG);

    glLineWidth(1);
    drawStrokeText("PRESS ENTER TO START", WIDTH/5.5, HEIGHT/2.5, 0, FONT_SIZE_NORMAL);
    drawStrokeText("Press Esc to Quit", WIDTH/1.8, HEIGHT/3.4, 0, FONT_SIZE_SMALL);
    drawStrokeText("By:\n\tS BALAJI PRASANNA (1PE12CS032)\n\tABHISHEK SENDHIL (1PE13CS005)",
     WIDTH/2, HEIGHT/7, 0, FONT_SIZE_SMALL);

}

void gameScreen() {

    drawBalloons();

    stringstream ss;
    ss << "Balloons hit: " << score;
    string scoreStr = ss.str();
    drawStrokeText(scoreStr.c_str(), WIDTH/3, 0.9*HEIGHT, 0, FONT_SIZE_SMALL);

    ss.str("");
    ss << "Level: " << gameLevel;
    string levelStr = ss.str();
    drawStrokeText(levelStr.c_str(), 0.8 * WIDTH, 0.9*HEIGHT, 0, FONT_SIZE_SMALL);

    if (notifyMsg) {
        int offset = (msg.size() >= 1) ? 20 * msg.size() : 0;
        drawStrokeText(msg.c_str(), WIDTH/2 - offset, 0.5 * HEIGHT, 0, FONT_SIZE_SMALL);
    }

    if (instructionMenuVisible)
        showInstructions();
}

void updateGameState() {
    bool allHit;
    switch (gameState) {
        case GAME_RESTART:
            notifyMsg = true;
            msg = "Restarting...";
            initGame();
            break;

        case ROUND_INIT:
            break;

        case ROUND_ACTIVE:
            //cout << "Round active " << endl;
            // Update position of all the ducks
            for (int i = 0; i < balloonIndices.size(); i++) {
                balloons[balloonIndices[i]].updatePos(gameSpeed);
            }

            // Check if any duck has flown away
            allHit = true;
            for (int i = 0; i < balloonIndices.size(); i++) {
                int a = balloonIndices[i];
                if (balloons[a].flewAway) {
                    gameState = GAME_OVER;
                    return;
                }
                if (balloons[a].alive)
                    allHit = false;
            }
//
            if (allHit) {
                gameState = ROUND_OVER;
                return;
            }

            break;

        case ROUND_OVER:
            notifyMsg = true;
            msg = "Starting New Round...";
            balloonCount++;
            gameSpeed += 0.5f;
            gameLevel++;
            gameState = ROUND_INIT;
            glutTimerFunc(2000, notifyGame, 6);
            break;

        case GAME_OVER:
            msg = "GAME OVER";
            notifyMsg = true;
            instructionMenuVisible = true;
            break;

        default:
            break;
    }
}

void fire(unsigned char key) {
    for (int i = 0; i < balloonIndices.size(); i++) {
        int a = balloonIndices[i];
        if (balloons[a].isHit(key)) {
            balloons[a].alive = false;
            score++;
        }
    }
}

void drawBalloons() {

    if (gameState == ROUND_ACTIVE | gameState == ROUND_OVER)
        for (int i = 0; i < balloonIndices.size(); i++) {
            balloons[balloonIndices[i]].draw();;
        }
}

void showInstructions() {
    drawBitmapText("Instructions:\n"
        "  q - Quit simulation\n"
        "  i - Toggle Instructions\n"
        "  r - Restart Game\n", 10, HEIGHT-50, 0);
}

void notifyGame(int val) {
    switch (val) {
        case 0:                        // Show "READY"
            notifyMsg = true;
            msg = "Ready";
            glutTimerFunc(1000, notifyGame, 1);
            break;

        case 1:
            msg = "3";
            glutTimerFunc(1000, notifyGame, 2);
            break;

        case 2:
            msg = "2";
            glutTimerFunc(1000, notifyGame, 3);
            break;

        case 3:
            msg = "1";
            glutTimerFunc(1000, notifyGame, 4);
            break;

        case 4:
            msg = "GO";
            glutTimerFunc(1000, notifyGame, 5);
            break;

        case 5:
            notifyMsg = false;
            gameState = ROUND_ACTIVE;
            break;

        case 6:
            notifyMsg = false;
            initRound();
            break;

        default:
            break;
    }
}
