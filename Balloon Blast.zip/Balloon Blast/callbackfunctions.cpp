#include <GL/freeglut.h>
#include "callbackfunctions.h"
#include "game.h"
#include <iostream>

using namespace std;

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glClearColor(0, 0, 0, 0);

    if (appState == START_SCREEN) {
        startScreen();
    } else if (appState == GAME_SCREEN) {
        gameScreen();
    }

    glFlush();
    glutSwapBuffers();
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, WIDTH, 0, HEIGHT, 0, 2);
    glMatrixMode(GL_MODELVIEW);
}

void idle() {
    updateGameState();
    glutPostRedisplay();
}

void normalKeys(unsigned char key, int x, int y) {
    switch (key) {
        case 27:    // ESC key
            if (appState == START_SCREEN)
                exit(EXIT_SUCCESS);
        case 13:    // Enter key
            if (appState == START_SCREEN) {
                appState = GAME_SCREEN;
                initGame();
            }
            break;
        case 'q':
            if (appState == GAME_SCREEN) {
                appState = START_SCREEN;
            }
            break;
        case 'i':
            instructionMenuVisible = !instructionMenuVisible;
            break;
        case 'r':
            if (appState == GAME_SCREEN)
                gameState = GAME_RESTART;
            break;
        default:
            if (appState == GAME_SCREEN) {
                fire(key);
            }
            break;
    }
}
