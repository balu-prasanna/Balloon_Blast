#include "balloon.h"
#include "fonts.h"
#include <iostream>
#include <cmath>

using namespace std;

Balloon::Balloon() {

}

void Balloon::draw() {
    // Only draw the balloon if it's still on the screen
    if (!flewAway && alive) {

        glPushMatrix();
        glLineWidth(5);

			glBegin(GL_LINE_LOOP);

				for(double i = 0; i < 2 * PI; i += PI / 16)
 					glVertex2f(pos.x + cos(i) * BALLOON_RAD_X, pos.y + sin(i) * BALLOON_RAD_Y);
			glEnd();

        glLineWidth(2);
        glBegin(GL_LINES);
            glVertex2d(pos.x, pos.y-30);
            glVertex2d(pos.x, pos.y-60);
        glEnd();
        glLineWidth(1);

        drawBitmapText(key, pos.x-4, pos.y-5, 0);
        glPopMatrix();
    }
}

void Balloon::updatePos(float gameSpeed) {
    if (alive) {
        pos.y += gameSpeed;

        if (pos.y > HEIGHT)
            flewAway = true;
    }
}

bool Balloon::isHit(char key) {
    if (alive && this->key[0] == key)
        return true;
    else
        return false;

}
